﻿
namespace AWS.ServiceWrapper.Requests.Search
{
    public class SearchByAuthorRequest : BaseRequest
    {
        public string Author { get; set; }
    }
}
