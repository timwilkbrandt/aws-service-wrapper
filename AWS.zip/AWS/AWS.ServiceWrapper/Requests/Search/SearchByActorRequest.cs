﻿
namespace AWS.ServiceWrapper.Requests.Search
{
    public class SearchByActorRequest : BaseRequest
    {
        public string Actor { get; set; }
    }
}
