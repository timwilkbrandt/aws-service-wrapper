﻿
namespace AWS.ServiceWrapper.Requests.Search
{
    public class SearchByTitleRequest : BaseRequest
    {
        public string Title { get; set; }
    }
}
