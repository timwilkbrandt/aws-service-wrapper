﻿
namespace AWS.ServiceWrapper.Requests.Search
{
    public class SearchByManufacturerRequest : BaseRequest
    {
        public string Manufacturer { get; set; }
    }
}
