﻿
namespace AWS.ServiceWrapper.Requests.Search
{
    public class SearchByNodeIdRequest : BaseRequest
    {
        public string BrowseNodeId { get; set; }
    }
}
