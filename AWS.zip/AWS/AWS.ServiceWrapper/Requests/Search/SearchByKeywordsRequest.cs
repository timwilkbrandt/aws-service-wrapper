﻿using System.Collections.Generic;

namespace AWS.ServiceWrapper.Requests.Search
{
    public class SearchByKeywordsRequest : BaseRequest
    {
        public List<string> Keywords { get; set; }
    }
}
