﻿
namespace AWS.ServiceWrapper.Requests.Search
{
    public class SearchByIdRequest : BaseRequest
    {

        public string ItemType { get; set; }

        public string ItemId { get; set; }

    }
}
