﻿using System.Configuration;
using System.Collections.Generic;
using System.Web;
using System;

using AWS.ServiceWrapper.Constants;

namespace AWS.ServiceWrapper.Requests.Search
{
    public class BaseRequest
    {

        public BaseRequest()
        {
            ResponseType = AWSConstants.ResponseType.JSON;
            QsParameters = new Dictionary<string, string>();
            Service = ConfigurationManager.AppSettings["CommerceService"].ToString(); 
        }

        public readonly string Service;

        public string Operation { get; set; }

        public string AccessKey { get; set; }

        public string Signature { get; set; }

        public string AssociateTag { get; set; }

        public List<string> ResponseGroup { get; set; }

        public string SearchIndex { get; set; }

        public string MerchantId { get; set; }
        
        public string Version {get;set;}

        public Dictionary<string, string> QsParameters { get; set; }

        public AWSConstants.ResponseType ResponseType { get; set; }

        public bool IsAvailable 
        { 
            set 
            { 
                if (value == true) 
                { 
                    QsParameters.Add(AWSCommonParamConstants.AWSAvailabilityParamName, "Available"); 
                }
                else
                {
                    QsParameters.Remove(AWSCommonParamConstants.AWSAvailabilityParamName);
                }
            } 
        }

    }
}
