﻿using AWS.ServiceWrapper.Models;

namespace AWS.ServiceWrapper.Responses.Search
{
    public class SearchResponse : BaseResponse
    {
        public ItemLookupModel Data { get; set; }
    }
}
