﻿
namespace AWS.ServiceWrapper.Responses.Search
{
    public class BaseResponse
    {

        public BaseResponse()
        {
            Success = true;
        }

        public bool Success { get; set; }

        public string ErrorMessage { get; set; }



    }
}
