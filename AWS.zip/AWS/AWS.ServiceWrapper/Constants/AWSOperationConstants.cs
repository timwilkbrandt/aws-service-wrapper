﻿

namespace AWS.ServiceWrapper.Constants
{
    public static class AWSOperationConstants
    {

        public const string NodeLookup =  "BrowseNodeLookup";

        public const string ItemLookup = "ItemLookup";

        public const string ItemSearch = "ItemSearch";

        public const string SimilarityLookup = "SimilarityLookup";

    }
}
