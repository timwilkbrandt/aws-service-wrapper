﻿

namespace AWS.ServiceWrapper.Constants
{
    public static class AWSConstants
    {

        //Endpoint
        public const string AWSHost = "http://webservices.amazon.com";

        public enum ResponseType { JSON = 1, XML = 2 };

    }
}
