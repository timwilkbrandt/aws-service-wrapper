﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AWS.ServiceWrapper.Constants
{
    public static class AWSCommonParamConstants
    {
        public const string AWSServiceParamName = "Service";
        public const string AWSOperationParamName = "Operation";
        public const string AWSAccessKeyParamName = "AWSAccessKeyId";
        public const string AWSTimestampParamName = "Timestamp";
        public const string AWSSignatureParamName = "Signature";
        public const string AWSAssociateTagParamName = "AssociateTag";
        public const string AWSResponseGroupParamName = "ResponseGroup";
        public const string AWSSearchIndexParamName = "SearchIndex";
        public const string AWSVersionParamName = "Version";
        public const string AWSMerchantIdParamName = "MerchantId";
        public const string AWSAvailabilityParamName = "Availability";
    }
}
