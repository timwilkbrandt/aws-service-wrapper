﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AWS.ServiceWrapper.Constants
{
    public static class AWSUniqueParamConstants
    {
        public const string AWSActorParamName = "Actor";
        public const string AWSTitleParamName = "Title";
        public const string AWSManufacturerParamName = "Manufacturer";
        public const string AWSAuthorParamName = "Author";
        public const string AWSItemIdParamName = "ItemId";
        public const string AWSItemTypeParamName = "ItemType";
        public const string AWSKeywordsParamName = "Keywords";
        public const string AWSBrowseNodeIdParamName = "BrowseNodeId";
    }
}
