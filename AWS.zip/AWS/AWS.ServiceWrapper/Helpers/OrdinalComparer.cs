﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AWS.ServiceWrapper.Helpers
{
    public class OrdinalComparer : IComparer<string>
    {
        public int Compare(string str1, string str2)
        {
            return string.Compare(str1, str2, StringComparison.Ordinal);
        }
    }
}
