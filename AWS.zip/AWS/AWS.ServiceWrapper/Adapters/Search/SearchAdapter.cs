﻿using System;

using AWS.ServiceWrapper.Responses.Search;
using AWS.ServiceWrapper.Requests.Search;
using AWS.ServiceWrapper.Constants;

namespace AWS.ServiceWrapper.Adapters.Search
{
    public class SearchAdapter : BaseAdapter, ISearchAdapter 
    {

        public SearchResponse SearchByActor(SearchByActorRequest request)
        {

            var response = new SearchResponse();

            try
            {
         
                if (!string.IsNullOrEmpty(request.Actor))
                    request.QsParameters.Add(AWSUniqueParamConstants.AWSActorParamName, request.Actor);

                response.Data = base.CallAmazonCommerceService(request);
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
                response.Success = false;
            }

            return response;
        }

        public SearchResponse SearchByTitle(SearchByTitleRequest request)
        {
            var response = new SearchResponse();

            try
            {

                if (!string.IsNullOrEmpty(request.Title))
                    request.QsParameters.Add(AWSUniqueParamConstants.AWSTitleParamName, request.Title);

                response.Data = base.CallAmazonCommerceService(request);
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
                response.Success = false;
            }

            return response;
        }

        public SearchResponse SearchByManufacturer(SearchByManufacturerRequest request)
        {
            var response = new SearchResponse();

            try
            {

                if (!string.IsNullOrEmpty(request.Manufacturer))
                    request.QsParameters.Add(AWSUniqueParamConstants.AWSManufacturerParamName, request.Manufacturer);

                response.Data = base.CallAmazonCommerceService(request);
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
                response.Success = false;
            }

            return response;
        }

        public SearchResponse SearchByAuthor(SearchByAuthorRequest request)
        {
            var response = new SearchResponse();

            try
            {

                if (!string.IsNullOrEmpty(request.Author))
                    request.QsParameters.Add(AWSUniqueParamConstants.AWSAuthorParamName, request.Author);

                response.Data = base.CallAmazonCommerceService(request);
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
                response.Success = false;
            }

            return response;
        }

        public SearchResponse SearchByItemId(SearchByIdRequest request)
        {

            var response = new SearchResponse();

            try
            {

                if (!string.IsNullOrEmpty(request.ItemId))
                    request.QsParameters.Add(AWSUniqueParamConstants.AWSItemIdParamName, request.ItemId);

                if (!string.IsNullOrEmpty(request.ItemType))
                    request.QsParameters.Add(AWSUniqueParamConstants.AWSItemTypeParamName, request.ItemType);

                response.Data = base.CallAmazonCommerceService(request);
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
                response.Success = false;
            }

            return response;

        }

        public SearchResponse SearchByKeywords(SearchByKeywordsRequest request)
        {

            var response = new SearchResponse();

            try
            {

                if (request.Keywords.Count > 0)
                {
                    var queryString = string.Join(",", request.Keywords.ToArray());
                    request.QsParameters.Add(AWSUniqueParamConstants.AWSKeywordsParamName, queryString);
                }
                    

                response.Data = base.CallAmazonCommerceService(request);
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
                response.Success = false;
            }

            return response;

        }

        public SearchResponse SearchByCategory(SearchByNodeIdRequest request)
        {
            var response = new SearchResponse();

            try
            {

                if (!string.IsNullOrEmpty(request.BrowseNodeId))
                    request.QsParameters.Add(AWSUniqueParamConstants.AWSBrowseNodeIdParamName, request.BrowseNodeId);

                response.Data = base.CallAmazonCommerceService(request);
            }
            catch (Exception ex)
            {
                response.ErrorMessage = ex.Message;
                response.Success = false;
            }

            return response;
        }
        
    }
}
