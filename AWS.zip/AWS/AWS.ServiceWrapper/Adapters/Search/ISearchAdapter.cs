﻿using AWS.ServiceWrapper.Requests.Search;
using AWS.ServiceWrapper.Responses.Search;

namespace AWS.ServiceWrapper.Adapters.Search
{
    interface ISearchAdapter
    {

        SearchResponse SearchByActor(SearchByActorRequest request);

        SearchResponse SearchByTitle(SearchByTitleRequest request);

        SearchResponse SearchByManufacturer(SearchByManufacturerRequest request);

        SearchResponse SearchByAuthor(SearchByAuthorRequest request);

        SearchResponse SearchByItemId(SearchByIdRequest request);

        SearchResponse SearchByKeywords(SearchByKeywordsRequest request);

    }
}
