﻿using System;
using System.Text;
using System.IO;
using System.Web;
using System.Net;
using System.Linq;
using System.Security.Cryptography;
using System.Xml.Serialization;
using System.Runtime.Serialization.Json;

using AWS.ServiceWrapper.Requests.Search;
using AWS.ServiceWrapper.Responses.Search;
using AWS.ServiceWrapper.Constants;
using AWS.ServiceWrapper.Models;
using AWS.ServiceWrapper.Helpers;

namespace AWS.ServiceWrapper.Adapters.Search
{
    public class BaseAdapter : IDisposable
    {
        private string _awsHost;
        private string _path;
        private BaseRequest _request;
        private System.Collections.Specialized.NameValueCollection _query;

        public BaseAdapter()
        {
            _path = "/onca";
            _query = System.Web.HttpUtility.ParseQueryString(String.Empty);
            _awsHost = AWSConstants.AWSHost;

        }

        public virtual ItemLookupModel CallAmazonCommerceService(BaseRequest request)
        {

            _request = request;

            SetPath();

            SetCommonParameters();

            OrderParameters();

            GenerateSignature();

            var uriBuilder = new UriBuilder(_awsHost);
            uriBuilder.Query = _query.ToString();

            var awsRequest = WebRequest.Create(uriBuilder.ToString());

            awsRequest.Method = "GET";
            var response = (HttpWebResponse)awsRequest.GetResponse();

            var stream = response.GetResponseStream();

            if (_request.ResponseType == AWSConstants.ResponseType.XML)
            {
                var xmlSerializer = new XmlSerializer(typeof(ItemLookupModel));

                return (ItemLookupModel)xmlSerializer.Deserialize(stream);

            }
            else
            {
                DataContractJsonSerializer jsonSerializer = new DataContractJsonSerializer(typeof(ItemLookupModel));

                return (ItemLookupModel)jsonSerializer.ReadObject(stream);
            }
        }

        private void SetPath()
        {
            if (_request.ResponseType == AWSConstants.ResponseType.XML)
                _path += "/xml";

            _awsHost += _path;
        }

        private void SetCommonParameters()
        {
            if (!string.IsNullOrEmpty(_request.Service))
                _request.QsParameters.Add(AWSCommonParamConstants.AWSServiceParamName, _request.Service);

            if (!string.IsNullOrEmpty(_request.Operation))
                _request.QsParameters.Add(AWSCommonParamConstants.AWSOperationParamName, _request.Operation);

            //Special
            if (!string.IsNullOrEmpty(_request.Signature))
                _request.QsParameters.Add(AWSCommonParamConstants.AWSServiceParamName, _request.Signature);

            if (!string.IsNullOrEmpty(_request.AssociateTag))
                _request.QsParameters.Add(AWSCommonParamConstants.AWSAssociateTagParamName, _request.AssociateTag);

            if (_request.ResponseGroup.Count > 0)
            {
                var queryString = string.Join(",", _request.ResponseGroup.ToArray());
                _request.QsParameters.Add(AWSCommonParamConstants.AWSResponseGroupParamName, queryString);
            }
                
            if (!string.IsNullOrEmpty(_request.SearchIndex))
                _request.QsParameters.Add(AWSCommonParamConstants.AWSSearchIndexParamName, _request.SearchIndex);

            if (!string.IsNullOrEmpty(_request.MerchantId))
                _request.QsParameters.Add(AWSCommonParamConstants.AWSMerchantIdParamName, _request.MerchantId);

            if (!string.IsNullOrEmpty(_request.Version))
                _request.QsParameters.Add(AWSCommonParamConstants.AWSVersionParamName, _request.Version);

            _request.QsParameters.Add(AWSCommonParamConstants.AWSTimestampParamName, DateTime.UtcNow.ToString("yyyy-mm-ddThh:mm:ssZ"));
        }

        private void OrderParameters()
        {
            var ordinalComparer = new OrdinalComparer();
            foreach (var queryParam in _request.QsParameters.OrderBy(a => a.Value, ordinalComparer))
            {
                _query[queryParam.Key] = queryParam.Value;
            };
        }

        private void GenerateSignature()
        {

            var builder = new StringBuilder("GET");
            builder.AppendLine("webservices.amazon.com");
            builder.AppendLine(_path);
            builder.AppendLine(_request.QsParameters.ToString());

            var hashGenerator = new HMACSHA256(Encoding.ASCII.GetBytes(_request.AccessKey));

            var hashAsBytes = hashGenerator.ComputeHash(Encoding.ASCII.GetBytes(builder.ToString()));

            _query[AWSCommonParamConstants.AWSSignatureParamName] = ASCIIEncoding.ASCII.GetString(hashAsBytes);
        }

        public void Dispose()
        {

        }
    }
}
